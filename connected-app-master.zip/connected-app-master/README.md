# Connected App

## How to build this application with docker
```
docker build -t <DOCKERHUB_USERNAME>/app:1.0 .
```
